namespace FormsBackgrounding.Messages
{
    public class DownloadFinishedMessage
    {
        public string Url { get; set; }

        public string FilePath { get; set; }
    }
}