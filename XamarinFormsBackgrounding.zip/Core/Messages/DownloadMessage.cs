namespace FormsBackgrounding.Messages
{
	public class DownloadMessage
	{
		public string Url { get; set; }
	}
}