namespace FormsBackgrounding.Messages
{
	public class StartLongRunningTaskMessage
	{
	}
}