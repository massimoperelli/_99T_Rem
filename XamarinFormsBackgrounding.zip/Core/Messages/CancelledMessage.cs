namespace FormsBackgrounding.Messages
{
	public class CancelledMessage
	{
	}
	
}