namespace FormsBackgrounding.Messages
{
	public class StopLongRunningTaskMessage
	{
	}
}