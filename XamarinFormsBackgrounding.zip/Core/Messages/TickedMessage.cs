namespace FormsBackgrounding.Messages
{
	public class TickedMessage
	{
		public string Message { get; set; }
	}
}